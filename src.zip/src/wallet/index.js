import Transaction from './transaction';
import Wallet from './wallet';

const blockchainWallet = new Wallet();

export { Transaction, blockchainWallet };
export default Wallet;